-- Creative Energy Management Technology
data:extend({
  {
    type = "technology",
    name = "creative-energy-management",
    icon = "__base__/graphics/technology/nuclear-power.png",
    icon_size = 256,
    icon_mipmaps = 4,
    prerequisites = {"nuclear-power"},
    effects = {
      {
        type = "unlock-recipe",
        recipe = "electric-energy-interface"
      }
    },
    unit = {
      count = 10000,
      ingredients = {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"military-science-pack", 1},
        {"chemical-science-pack", 1},
        {"production-science-pack", 1},
        {"utility-science-pack", 1},
        {"space-science-pack", 1}
      },
      time = 60
    },
    order = "z-z-z" -- Place it at the end
  }
})

-- Electric Energy Interface Recipe
data:extend({
  {
    type = "recipe",
    name = "electric-energy-interface",
    enabled = false,
    ingredients = {
      {type="item", name="nuclear-reactor", amount=1},
      {type="item", name="processing-unit", amount=1000},
      {type="item", name="advanced-circuit", amount=1000},
      {type="item", name="steel-plate", amount=1000},
      {type="item", name="low-density-structure", amount=500}
    },
    results = {
      {type="item", name="electric-energy-interface", amount=1}
    }
  }
})