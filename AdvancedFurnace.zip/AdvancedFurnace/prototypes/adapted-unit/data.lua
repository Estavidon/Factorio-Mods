-- Item definition
data:extend({
  {
    type = "item",
    name = "adapted-unit",
    icon = "__AdvancedFurnace__/graphics/icons/adapted-unit.png",
    icon_size = 64, -- Assuming the user's image is 64x64
    icon_mipmaps = 4,
    subgroup = "intermediate-product",
    order = "g-a", -- Placing it after processing unit
    stack_size = 200
  }
})

-- Recipe definition
data:extend({
  {
    type = "recipe",
    name = "adapted-unit",
    enabled = false,
    ingredients = {
      {type="item", name="processing-unit", amount=1},
      {type="item", name="plastic-bar", amount=5},
      {type="item", name="copper-cable", amount=10}
    },
    results = {
      {type="item", name="adapted-unit", amount=1}
    }
  }
})

-- Technology definition
data:extend({
  {
    type = "technology",
    name = "adapted-unit-technology",
    icon = "__AdvancedFurnace__/graphics/technology/adapted-unit-technology.png",
    icon_size = 256,
    icon_mipmaps = 4,
    prerequisites = {"chemical-science-pack"},
    effects = {
      {
        type = "unlock-recipe",
        recipe = "adapted-unit"
      }
    },
    unit = {
      count = 200,
      ingredients = {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1}
      },
      time = 30
    },
    order = "g-a"
  }
})
