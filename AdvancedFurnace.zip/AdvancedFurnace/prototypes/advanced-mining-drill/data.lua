-- Get the electric mining drill definition
local electric_mining_drill = table.deepcopy(data.raw["mining-drill"]["electric-mining-drill"])

-- Modify the properties
electric_mining_drill.name = "advanced-electric-mining-drill"
electric_mining_drill.minable = {mining_time = 1, result = "advanced-electric-mining-drill"}
electric_mining_drill.mining_speed = 2 -- 4x faster than 0.5
electric_mining_drill.energy_usage = "108kW" -- 20% more than 90kW
electric_mining_drill.fast_replaceable_group = "mining-drill"


-- Create the new entity
data:extend({electric_mining_drill})

-- Create the item
data:extend({
  {
    type = "item",
    name = "advanced-electric-mining-drill",
    icon = "__base__/graphics/icons/electric-mining-drill.png",
    icon_size = 64,
    icon_mipmaps = 4,
    subgroup = "extraction-machine",
    order = "a[mining]-c[advanced-electric-mining-drill]",
    place_result = "advanced-electric-mining-drill",
    stack_size = 50
  }
})

-- Create the recipe
data:extend({
  {
    type = "recipe",
    name = "advanced-electric-mining-drill",
    enabled = false, -- To be unlocked by research
    ingredients =
    {
      {type="item", name="electric-mining-drill", amount=1},
      {type="item", name="steel-plate", amount=20},
      {type="item", name="processing-unit", amount=5}
    },
    results = 
    {
      {type="item", name="advanced-electric-mining-drill", amount=1}
    }
  }
})

-- New technology for the advanced drill
data:extend({
  {
    type = "technology",
    name = "advanced-mining-technology",
    icon = "__base__/graphics/technology/electronics.png", -- Using electronics icon for now
    icon_size = 256,
    prerequisites = {"electronics"},
    effects = {
      {
        type = "unlock-recipe",
        recipe = "advanced-electric-mining-drill"
      }
    },
    unit = {
      count = 150,
      ingredients = {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1}
      },
      time = 30
    },
    order = "c-k-b" -- Placing it after advanced electronics
  }
})