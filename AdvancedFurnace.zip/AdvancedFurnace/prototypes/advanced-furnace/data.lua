-- Get the electric furnace definition
local electric_furnace = table.deepcopy(data.raw["furnace"]["electric-furnace"])

-- Modify the properties
electric_furnace.name = "advanced-furnace"
electric_furnace.crafting_speed = 15
electric_furnace.energy_usage = "90kW"

-- Add the power supply
electric_furnace.energy_source.drain = "30kW"
electric_furnace.supply_area_distance = 5

-- Create the new entity
data:extend({electric_furnace})

-- Create the item
data:extend({
  {
    type = "item",
    name = "advanced-furnace",
    icon = "__base__/graphics/icons/electric-furnace.png",
    icon_size = 64,
    subgroup = "smelting-machine",
    order = "a[smelting]-c[advanced-furnace]",
    place_result = "advanced-furnace",
    stack_size = 50
  }
})

-- Create the recipe
data:extend({
  {
    type = "recipe",
    name = "advanced-furnace",
    enabled = false,
    ingredients =
    {
      {type="item", name="electric-furnace", amount=1},
      {type="item", name="processing-unit", amount=5},
      {type="item", name="steel-plate", amount=20}
    },
    results = 
    {
      {type="item", name="advanced-furnace", amount=1}
    }
  }
})

-- Add the recipe to the technology
table.insert(data.raw.technology["advanced-material-processing-2"].effects, {type = "unlock-recipe", recipe = "advanced-furnace"})
