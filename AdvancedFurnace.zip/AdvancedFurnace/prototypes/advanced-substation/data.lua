-- Get the substation definition
local substation = table.deepcopy(data.raw["electric-pole"]["substation"])

-- Modify the properties
substation.name = "advanced-substation"
substation.minable = {mining_time = 1, result = "advanced-substation"}
substation.supply_area_distance = 27 -- 3x larger than 9
substation.maximum_wire_distance = 36 -- Increased from 18

-- Create the new entity
data:extend({substation})

-- Create the item
data:extend({
  {
    type = "item",
    name = "advanced-substation",
    icon = "__base__/graphics/icons/substation.png",
    icon_size = 64,
    icon_mipmaps = 4,
    subgroup = "energy-pipe-distribution",
    order = "c[substation]-b[advanced-substation]",
    place_result = "advanced-substation",
    stack_size = 50
  }
})

-- Create the recipe
data:extend({
  {
    type = "recipe",
    name = "advanced-substation",
    enabled = false, -- To be unlocked by research
    ingredients =
    {
      {type="item", name="substation", amount=1},
      {type="item", name="advanced-circuit", amount=10},
      {type="item", name="copper-cable", amount=20},
      {type="item", name="steel-plate", amount=10}
    },
    results =
    {
      {type="item", name="advanced-substation", amount=1}
    }
  }
})

-- Add the recipe to the technology
table.insert(data.raw.technology["electric-energy-distribution-2"].effects, {type = "unlock-recipe", recipe = "advanced-substation"})
