# AdvancedFurnace Mod

This file tracks the development plan and progress for the AdvancedFurnace mod.

## Author

*   Est1

## How to Update

Run the `update_mod.bat` script to automatically download and install the latest version of the mod from GitHub.

## Mod Structure

The mod is structured to be modular. Each feature is contained in its own directory under the `prototypes` directory.

*   `prototypes/advanced-furnace/`: Contains the code for the "Advanced Electric Furnace".
*   `prototypes/advanced-mining-drill/`: Contains the code for the "Advanced Electric Drill".
*   `prototypes/advanced-substation/`: Contains the code for the "Advanced Substation".
*   `prototypes/creative-items/`: Contains the recipe for the "Electric Energy Interface".
*   `prototypes/adapted-unit/`: Contains the code for the "Adapted Unit" circuit.

## Features

### Advanced Electric Furnace
*   **Crafting Speed:** 15 (vanilla is 2)
*   **Energy Consumption:** 90kW
*   **Supply Area:** 5 tiles (powers nearby entities like inserters)
*   **Research:** Unlocked with `advanced-material-processing-2`.

### Advanced Electric Drill
*   **Mining Speed:** 2 (4x faster than vanilla's 0.5)
*   **Energy Consumption:** 108kW (20% more than vanilla)
*   **Research:** Unlocked by a new "Advanced Mining Technology" after `electronics`.

### Advanced Substation
*   **Supply Radius:** 27 (3x larger than vanilla's 9)
*   **Research:** Unlocked with `electric-energy-distribution-2`.

### Adapted Unit
*   A new intermediate circuit for late-game recipes.
*   **Recipe:** 1x Processing Unit, 5x Plastic Bar, 10x Copper Cable.
*   **Research:** Unlocked by a new "Adaptive Circuit Technology" after `chemical-science-pack`.

### Electric Energy Interface
*   Adds a very expensive, late-game recipe for the creative mode item.
*   **Research:** Unlocked by a new "Creative Energy Management" technology after `nuclear-power`.

All items and technologies have Russian localization.
